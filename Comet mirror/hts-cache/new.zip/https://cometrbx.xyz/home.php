<!DOCTYPE html>
<html lang="en" style="width: 100%;">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Comet 3 - Innovative Game Genie</title>
    <meta name="description" content="Comet 3 is one of the best modern game genies. It can help you to achieve your goals. Whether it's to become the best shooter gamer. Or to get a million coins!">
    <meta name="twitter:description" content="彗星3是最好的现代游戏精灵之一。它可以帮助你实现你的目标。无论是成为最好的射击游戏玩家。还是要获得100万个硬币!">
    <meta name="twitter:image" content="assets/img/CometFrontPageImage2.png">
    <meta name="twitter:title" content="Comet 3 - 创新的游戏精灵，公平的竞争环境。">
    <meta property="og:image" content="assets/img/CometFrontPageImage2.png">
    <link rel="icon" type="image/png" sizes="512x512" href="assets/img/MERCURYLOGO.png">
    <link rel="icon" type="image/png" sizes="512x512" href="assets/img/MERCURYLOGO.png">
    <link rel="icon" type="image/png" sizes="512x512" href="assets/img/MERCURYLOGO.png">
    <link rel="icon" type="image/png" sizes="512x512" href="assets/img/MERCURYLOGO.png">
    <link rel="icon" type="image/png" sizes="512x512" href="assets/img/MERCURYLOGO.png">
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/Atkinson%20Hyperlegible.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Inter">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto">
    <link rel="stylesheet" href="assets/css/Animated-numbers-section.css">
    <link rel="stylesheet" href="assets/css/Features-Boxed.css">
    <link rel="stylesheet" href="assets/css/Footer-Basic.css">
    <link rel="stylesheet" href="assets/css/Header-Blue.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/baguettebox.js/1.10.0/baguetteBox.min.css">
    <link rel="stylesheet" href="assets/css/Lightbox-Gallery.css">
    <link rel="stylesheet" href="assets/css/styles.css">
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-7469871175420181" crossorigin="anonymous"></script>
</head>

<body style="background: rgb(10,10,10);">
    <div class="container text-start d-flex d-xl-flex align-items-center align-items-xl-center" data-aos="slide-down" style="max-width: none;padding: 0px;height: 40px;background: rgb(15,15,15);">
        <h2 class="d-flex d-xl-flex align-items-center justify-content-xl-start align-items-xl-center" style="margin: 0px;margin-top: 0px;color: rgb(255,255,255);font-family: 'Atkinson Hyperlegible';font-weight: norm;font-size: 15px;text-align: left;margin-left: 30px;font-style: normal;">Supercomet Labs</h2>
    </div>
    <div class="container" style="max-width: none;padding: 0px;height: 900px;padding-bottom: 250px;background: url(&quot;assets/img/CometFrontPageImage2.png&quot;) center / cover no-repeat, rgba(153,179,228,0);">
        <nav class="navbar navbar-light navbar-expand-sm" style="padding: 30px;">
            <div class="container-fluid"><button data-bs-toggle="collapse" class="navbar-toggler text-white" data-bs-target="#navcol-1" style="color: #ffffff;font-family: 'Atkinson Hyperlegible';border-style: none;border-radius: 0px;box-shadow: 0px 0px;filter: invert(100%);"><span class="visually-hidden" style="color: #ffffff;font-family: 'Atkinson Hyperlegible';">Toggle navigation</span><span class="navbar-toggler-icon text-white border-white shadow-none" style="color: #ffffff;font-family: 'Atkinson Hyperlegible';filter: brightness(50%) contrast(100%);"></span></button><a href="#"><img style="height: 50px;width: 50px;" src="assets/img/MERCURYLOGO.png"></a>
                <div class="collapse navbar-collapse d-sm-flex d-md-flex d-xl-flex justify-content-sm-center justify-content-md-center justify-content-xl-center" id="navcol-1" style="color: #ffffff;font-family: 'Atkinson Hyperlegible';margin-right: 50px;">
                    <ul class="navbar-nav" style="color: #ffffff;font-family: 'Atkinson Hyperlegible';">
                        <li class="nav-item" style="color: #ffffff;font-family: 'Atkinson Hyperlegible';"><a class="nav-link active" href="#" style="color: #ffffff;font-family: 'Atkinson Hyperlegible';font-weight: 500;">Home</a></li>
                        <li class="nav-item" style="color: #ffffff;font-family: 'Atkinson Hyperlegible';font-weight: 500;"><a class="nav-link active" href="download.html" style="color: #ffffff;font-family: 'Atkinson Hyperlegible';font-weight: 500;">Download</a></li>
                        <li class="nav-item" style="color: #ffffff;font-family: 'Atkinson Hyperlegible';font-weight: 500;"><a class="nav-link active" href="suggestions.html" style="color: #ffffff;font-family: 'Atkinson Hyperlegible';font-weight: 500;">Suggestions</a></li>
                        <li class="nav-item" style="color: #ffffff;font-family: 'Atkinson Hyperlegible';font-weight: 500;">
                            <div class="nav-item dropdown" style="color: rgb(255,255,255);padding: 8px;font-family: 'Atkinson Hyperlegible';"><a aria-expanded="false" data-bs-toggle="dropdown" href="#" style="color: #ffffff;border-style: none;font-family: 'Atkinson Hyperlegible';">Support</a>
                                <div class="dropdown-menu"><a class="dropdown-item" href="discord.html">Support (Discord Server)</a><a class="dropdown-item" href="supportapp.html">Apply to our Support Team!</a></div>
                            </div>
                        </li>
                        <li class="nav-item" style="color: #ffffff;font-family: 'Atkinson Hyperlegible';font-weight: 500;">
                            <div class="nav-item dropdown" style="color: rgb(255,255,255);padding: 8px;font-family: 'Atkinson Hyperlegible';"><a aria-expanded="false" data-bs-toggle="dropdown" href="#" style="color: #ffffff;border-style: none;font-family: 'Atkinson Hyperlegible';">About</a>
                                <div class="dropdown-menu"><a class="dropdown-item" href="about.html">About Us</a><a class="dropdown-item" href="eula.html">EULA</a></div>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <div class="col">
            <div class="row" style="margin: 0px;padding: 20px;width: 100%;">
                <div class="col" style="padding-left: 25px;padding-right: 25px;">
                    <div class="row">
                        <div class="col">
                            <h1 data-aos="fade-up" style="margin: 0px;margin-top: 0px;color: rgb(255,255,255);font-family: Poppins, sans-serif;font-weight: 400px;font-size: 40px;text-align: center;">Comet 3</h1>
                            <h1 data-aos="fade-up" data-aos-delay="200" style="margin: 0px;margin-top: 0px;color: rgb(255,255,255);font-family: Poppins, sans-serif;font-weight: 400;font-size: 20px;text-align: center;">Innovative Game Genie, Change the World.</h1>
                        </div>
                    </div>
                    <div class="row" style="font-family: 'Atkinson Hyperlegible';">
                        <div class="col" style="padding: 0px;padding-top: 10px;margin: 0px;margin-left: 5px;text-align: center;font-family: 'Atkinson Hyperlegible';"><a class="btn btn-primary" role="button" data-aos="fade-up" data-aos-delay="400" style="background: rgb(255,255,255);border-style: none;font-family: Poppins, sans-serif;font-weight: 500;border-radius: 5px;box-shadow: 0px 0px 5px rgb(255,255,255);padding: 9px;height: 40px;width: 180px;margin: 5px;margin-top: 5px;margin-bottom: 5px;color: rgb(154,162,181);" href="download.html">Download Comet 3</a></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container" style="max-width: none;padding: 0px;height: auto;padding-bottom: 100px;margin-top: 0px;">
        <section class="d-flex d-sm-flex d-md-flex d-xl-flex d-xxl-flex justify-content-center justify-content-sm-center justify-content-md-center justify-content-xl-center justify-content-xxl-center photo-gallery" style="background: rgba(255,255,255,0);">
            <div class="container" style="padding: 0px;margin: 0px;">
                <div class="intro" style="width: 100%;max-width: 100%;margin: 0px;padding-right: 10px;padding-left: 10px;">
                    <h1 data-aos="fade-up" data-aos-delay="300" data-aos-once="true" style="padding: 50px;color: rgb(255,255,255);font-family: Poppins, sans-serif;font-size: 60px;font-weight: 600;padding-bottom: 0px;padding-right: 0;padding-left: 0;">Design</h1>
                    <h1 data-aos="fade-up" data-aos-delay="700" data-aos-once="true" style="padding: 0px;color: rgb(255,255,255);font-family: Poppins, sans-serif;font-size: 25px;font-weight: 400;padding-bottom: 5px;padding-right: 0;padding-left: 0;">Comet 3 is well-known for it's true design quality. We design our Scripting System in-house to create the best experience for our users. Our designs are renowned for their unique quality.</h1>
                </div>
                <div class="row text-center d-flex justify-content-center photos" data-bss-baguettebox="" style="margin: 0px;padding: 0px;margin-left: 0px;">
                    <div class="col-sm-6 col-md-4 col-lg-3 item" data-aos="zoom-in-right" data-aos-delay="1200" data-aos-once="true" style="width: 306px;height: 306px;max-width: 306px;padding: 0px;margin: 10px;"><a href="assets/img/CometPhoto1.png"><img class="img-fluid" src="assets/img/GenericTransparent.png" style="width: 100%;max-width: 100%;height: 306px;background: url(&quot;assets/img/CometPhoto1.png&quot;) center / cover no-repeat;"></a></div>
                    <div class="col-sm-6 col-md-4 col-lg-3 item" data-aos="zoom-in-right" data-aos-delay="1400" data-aos-once="true" style="width: 306px;height: 306px;max-width: 306px;padding: 0px;margin: 10px;"><a href="assets/img/CometPhoto2.png"><img class="img-fluid" src="assets/img/GenericTransparent.png" style="width: 100%;max-width: 100%;height: 306px;background: url(&quot;assets/img/CometPhoto2.png&quot;) center / cover no-repeat;"></a></div>
                    <div class="col-sm-6 col-md-4 col-lg-3 item" data-aos="zoom-in-right" data-aos-delay="1600" data-aos-once="true" style="width: 306px;height: 306px;max-width: 306px;padding: 0px;margin: 10px;"><a href="assets/img/CometPhoto3.png"><img class="img-fluid" src="assets/img/GenericTransparent.png" style="width: 100%;max-width: 100%;height: 306px;background: url(&quot;assets/img/CometPhoto3.png&quot;) center / cover no-repeat;"></a></div>
                    <div class="col-sm-6 col-md-4 col-lg-3 item" data-aos="zoom-in-right" data-aos-delay="1800" data-aos-once="true" style="width: 306px;height: 306px;max-width: 306px;padding: 0px;margin: 10px;"><a href="assets/img/CometPhoto4.png"><img class="img-fluid" src="assets/img/GenericTransparent.png" style="width: 100%;max-width: 100%;height: 306px;background: url(&quot;assets/img/CometPhoto4.png&quot;) center / cover no-repeat;"></a></div>
                </div>
            </div>
        </section>
        <section class="d-flex d-sm-flex d-md-flex d-xl-flex d-xxl-flex justify-content-center align-items-center justify-content-sm-center justify-content-md-center justify-content-xl-center justify-content-xxl-center photo-gallery" style="background: rgba(255,255,255,0);margin-top: 20px;margin-bottom: 20px;">
            <div class="container" style="padding: 0px;margin: 0px;">
                <div class="row text-center d-flex justify-content-center photos" data-bss-baguettebox="" style="margin: 0px;padding: 0px;margin-left: 0px;height: auto;">
                    <div class="col-sm-12 col-md-12 col-lg-12 col-xl-4 col-xxl-5 d-flex d-sm-flex d-md-flex d-lg-flex d-xl-flex d-xxl-flex justify-content-center align-items-center justify-content-sm-center align-items-sm-center justify-content-md-center align-items-md-center justify-content-lg-center align-items-lg-center align-items-xl-center align-items-xxl-center item" style="height: auto;max-width: 100%;padding: 0px;margin: 0px;padding-right: 10px;padding-left: 10px;margin-right: 0px;">
                        <div class="row" style="margin: 0px;width: 100%;">
                            <div class="col text-start" style="padding: 0px;">
                                <h1 data-aos="fade-up" data-aos-delay="500" style="margin: 0px;margin-top: 0px;color: rgb(255,255,255);font-family: Poppins, sans-serif;font-weight: 600;font-size: 50px;text-align: left;">Dreamforce F3 Execution Engine</h1>
                                <h1 data-aos="fade-up" data-aos-delay="750" data-aos-once="true" style="margin: 0px;margin-top: 10px;color: rgb(255,255,255);font-family: Poppins, sans-serif;font-weight: 400;font-size: 20px;text-align: left;">The Dreamforce F3 Execution Engine is incredible. Reaching up to 97% Compatibility with Scripts and reaching speeds faster than 99% of comparable products out in the market right now. The Dreamforce F3 Execution Engine is UNC-Compliant.</h1>
                                <h1 data-aos="fade-up" data-aos-delay="950" data-aos-once="true" style="margin: 0px;margin-top: 40px;color: rgb(255,255,255);font-family: Poppins, sans-serif;font-weight: 400;font-size: 20px;text-align: left;">Comet 3 Benchmark Speed:</h1><img data-aos="zoom-out-right" data-aos-delay="1050" data-aos-once="true" src="assets/img/CometProgress1.png" style="width: 192px;margin-left: -19px;font-family: Poppins, sans-serif;">
                                <h1 data-aos="fade-up" data-aos-delay="1150" data-aos-once="true" style="margin: 0px;margin-top: 0px;color: rgb(255,255,255);font-family: Poppins, sans-serif;font-weight: 400;font-size: 20px;text-align: left;">API-Based Executor Benchmark Speed:</h1><img data-aos="zoom-out-right" data-aos-delay="1250" data-aos-once="true" src="assets/img/CometProgress2.png" style="width: 100%;margin-left: -19px;max-width: 360px;">
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-8 col-xxl-7 offset-sm-3 d-xl-flex d-xxl-flex align-items-xl-center justify-content-xxl-end align-items-xxl-center item" data-aos="fade-left" data-aos-delay="500" data-aos-once="true" style="height: 481px;max-width: auto;padding: 0px;margin: 0px;background: url(&quot;assets/img/CometCPUModel.png&quot;) center / cover no-repeat;padding-right: 0px;padding-left: 0px;margin-right: 0px;">
                        <header></header>
                    </div>
                </div>
            </div>
        </section>
        <section class="d-flex d-sm-flex d-md-flex d-xxl-flex justify-content-center justify-content-sm-center justify-content-md-center justify-content-xxl-center photo-gallery" style="background: url(&quot;assets/img/Comet3GameIntegration.png&quot;) bottom / cover no-repeat, rgba(255,255,255,0);height: 1000px;">
            <div class="container" style="padding: 0px;margin: 0px;">
                <div class="intro" style="width: 100%;max-width: 100%;margin: 0px;padding-right: 10px;padding-left: 10px;">
                    <h1 data-aos="fade-up" data-aos-duration="500" data-aos-once="true" style="padding: 50px;color: rgb(255,255,255);font-family: Poppins, sans-serif;font-size: 50px;font-weight: 600;padding-bottom: 0px;padding-right: 0;padding-left: 0;text-align: center;">Comet x ScriptBlox</h1>
                    <h1 data-aos="fade-up" data-aos-delay="700" data-aos-once="true" style="padding: 0px;color: rgb(255,255,255);font-family: Poppins, sans-serif;font-size: 25px;font-weight: 400;padding-bottom: 5px;padding-right: 0;padding-left: 0;text-align: center;">We have integrated ScriptBlox into Comet 3 to provide you with fresh scripts every hour! We also provide you with features like Script Rating, Comments, and more!</h1>
                </div>
            </div>
        </section>
        <section class="d-flex d-sm-flex d-md-flex d-xxl-flex justify-content-center justify-content-sm-center justify-content-md-center justify-content-xxl-center photo-gallery" style="background: rgba(255,255,255,0);">
            <div class="container" style="padding: 0px;margin: 0px;">
                <div class="intro" style="width: 100%;max-width: 100%;margin: 0px;padding-right: 10px;padding-left: 10px;">
                    <h1 style="padding: 50px;color: rgb(255,255,255);font-family: Poppins, sans-serif;font-size: 60px;font-weight: 600;padding-bottom: 0px;padding-right: 0;padding-left: 0;">Frequently Asked Questions (FAQ)</h1>
                    <h1 style="padding: 0px;color: rgb(255,255,255);font-family: Poppins, sans-serif;font-size: 25px;font-weight: 400;padding-bottom: 5px;padding-right: 0;padding-left: 0;">Have a question? We offer answers to a few of them below.</h1>
                </div>
                <div class="row" style="width: 100%;margin: 0px;font-family: Poppins, sans-serif;">
                    <div class="col d-flex d-xxl-flex justify-content-center justify-content-xxl-center" style="padding: 0px;font-family: Poppins, sans-serif;">
                        <div role="tablist" id="accordion-1" style="width: 100%;font-family: Poppins, sans-serif;">
                            <div class="card" style="background: rgb(10,10,10);font-family: Poppins, sans-serif;">
                                <div class="card-header" role="tab" style="border-style: none;border-color: rgb(25,25,25);background: rgb(25,25,25);font-family: Poppins, sans-serif;">
                                    <h5 class="mb-0" style="font-family: Poppins, sans-serif;"><a data-bs-toggle="collapse" aria-expanded="true" aria-controls="accordion-1 .item-1" href="#accordion-1 .item-1" style="color: rgb(255,255,255);font-family: Poppins, sans-serif;font-weight: 400600;font-size: 18px;">Is Comet a Virus?</a></h5>
                                </div>
                                <div class="collapse show item-1" role="tabpanel" data-bs-parent="#accordion-1" style="color: rgb(255,255,255);font-family: Poppins, sans-serif;">
                                    <div class="card-body">
                                        <p class="card-text" style="font-family: Poppins, sans-serif;">No, and since Comet is not obfuscated, you can even read Comet Code itself using DNSpy and check if it is a virus or not. If you want to download DNSpy, download it from the button below.</p><a class="btn btn-primary" role="button" style="background: rgb(25,25,25);border-style: none;font-family: Poppins, sans-serif;font-weight: 500;border-radius: 5px;box-shadow: 0px 0px 5px rgb(25,25,25);padding: 9px;height: 40px;width: 180px;margin: 5px;margin-top: 5px;margin-bottom: 5px;" href="https://github.com/dnSpy/dnSpy">Download DNSpy</a>
                                    </div>
                                </div>
                            </div>
                            <div class="card" style="background: rgb(10,10,10);font-family: Poppins, sans-serif;">
                                <div class="card-header" role="tab" style="border-style: none;border-color: rgb(25,25,25);background: rgb(25,25,25);font-family: Poppins, sans-serif;">
                                    <h5 class="mb-0" style="font-family: Poppins, sans-serif;"><a data-bs-toggle="collapse" aria-expanded="false" aria-controls="accordion-1 .item-2" href="#accordion-1 .item-2" style="color: rgb(255,255,255);font-family: Poppins, sans-serif;font-weight: 400600;font-size: 18px;">Why is Comet Flagged as a virus?</a></h5>
                                </div>
                                <div class="collapse item-2" role="tabpanel" data-bs-parent="#accordion-1" style="color: rgb(255,255,255);font-family: Poppins, sans-serif;">
                                    <div class="card-body">
                                        <p class="card-text" style="font-family: Poppins, sans-serif;">The nature of programs like Comet makes it easy for Antiviruses to falsely flag us as such. Injecting into Programs is an action some viruses do make. But in this case, you have control over when you want to Inject into the program.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="card" style="background: rgb(10,10,10);font-family: Poppins, sans-serif;">
                                <div class="card-header" role="tab" style="border-style: none;border-color: rgb(25,25,25);background: rgb(25,25,25);font-family: Poppins, sans-serif;">
                                    <h5 class="mb-0" style="font-family: Poppins, sans-serif;"><a data-bs-toggle="collapse" aria-expanded="false" aria-controls="accordion-1 .item-3" href="#accordion-1 .item-3" style="color: rgb(255,255,255);font-family: Poppins, sans-serif;font-weight: 400600;font-size: 18px;">Will Comet support more scripts?</a></h5>
                                </div>
                                <div class="collapse item-3" role="tabpanel" data-bs-parent="#accordion-1" style="color: rgb(255,255,255);font-family: Poppins, sans-serif;">
                                    <div class="card-body">
                                        <p class="card-text" style="font-family: Poppins, sans-serif;">Yes, Overtime we will add more functions that will allow us to run harder-to-run scripts.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="card" style="background: rgb(10,10,10);font-family: Poppins, sans-serif;">
                                <div class="card-header" role="tab" style="border-style: none;border-color: rgb(25,25,25);background: rgb(25,25,25);font-family: Poppins, sans-serif;">
                                    <h5 class="mb-0" style="font-family: Poppins, sans-serif;"><a data-bs-toggle="collapse" aria-expanded="false" aria-controls="accordion-1 .item-4" href="#accordion-1 .item-4" style="color: rgb(255,255,255);font-family: Poppins, sans-serif;font-weight: 400600;font-size: 18px;">Will Comet have more features?</a></h5>
                                </div>
                                <div class="collapse item-4" role="tabpanel" data-bs-parent="#accordion-1" style="color: rgb(255,255,255);font-family: Poppins, sans-serif;">
                                    <div class="card-body">
                                        <p class="card-text" style="font-family: Poppins, sans-serif;">Yes, we're considering some new features like Themes.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="card" style="background: rgb(10,10,10);font-family: Poppins, sans-serif;">
                                <div class="card-header" role="tab" style="border-style: none;border-color: rgb(25,25,25);background: rgb(25,25,25);font-family: Poppins, sans-serif;">
                                    <h5 class="mb-0" style="font-family: Poppins, sans-serif;"><a data-bs-toggle="collapse" aria-expanded="false" aria-controls="accordion-1 .item-5" href="#accordion-1 .item-5" style="color: rgb(255,255,255);font-family: Poppins, sans-serif;font-weight: 400600;font-size: 18px;">Will Comet have a Decompiler?</a></h5>
                                </div>
                                <div class="collapse item-5" role="tabpanel" data-bs-parent="#accordion-1" style="color: rgb(255,255,255);font-family: Poppins, sans-serif;">
                                    <div class="card-body">
                                        <p class="card-text" style="font-family: Poppins, sans-serif;">No.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
    <footer class="footer-basic" style="background: rgba(255,255,255,0);font-family: Poppins, sans-serif;">
        <p class="copyright" style="font-family: Poppins, sans-serif;font-size: 15px;color: rgb(204,204,204);">Copyright © Supercomet Technology, 2021 - 2022<br></p>
    </footer>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/bs-init.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/baguettebox.js/1.10.0/baguetteBox.min.js"></script>
    <script src="assets/js/3D_CSS_PROGRESS_BAR_BY_REDSTAPLER.js"></script>
    <script src="assets/js/Animated-numbers-section.js"></script>
    <script src="assets/js/Lightbox-Gallery.js"></script>
</body>

</html>